// (c) 2017 ABBYY Production LLC
// SAMPLES code is property of ABBYY, exclusive rights are reserved. 
//
// DEVELOPER is allowed to incorporate SAMPLES into his own APPLICATION and modify it under 
// the  terms of  License Agreement between  ABBYY and DEVELOPER.


// Auto-generated config-file for FineReader Engine C++ samples

#ifndef FRE_SAMPLES_CONFIG_H
#define FRE_SAMPLES_CONFIG_H

// Return full path to FRE dll
static wchar_t* GetFreDllPath() {
	return L"C:\\Program Files\\ABBYY SDK\\12\\FineReader Engine\\Bin64\\FREngine.dll";
	//return L"C:\\Program Files (x86)\\Micro Focus\\Unified Functional Testing\\bin\\FREngine\\FREngine.dll";

}

// Return customer project id for FRE
static wchar_t* GetCustomerProjectId() {
	return L"JYB7VXmncFYRx26P3Hzg";
}

// Return path to license file
static wchar_t* GetLicensePath() {
	return L"";
}

// Return license password
static wchar_t* GetLicensePassword() {
	return L"";
}

// Return full path to Samples directory
static wchar_t* GetSamplesFolder() {
	return L"..\\..";
}

#define VisualComponentsDllPath "C:\\Program Files\\ABBYY SDK\\12\\FineReader Engine\\Bin64\\VisualComponentsX.dll"

#endif // FRE_SAMPLES_CONFIG_H
