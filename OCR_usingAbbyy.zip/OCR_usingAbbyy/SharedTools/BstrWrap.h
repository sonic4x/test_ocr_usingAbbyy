// � 2017 ABBYY Production LLC
// SAMPLES code is property of ABBYY, exclusive rights are reserved. 
//
// DEVELOPER is allowed to incorporate SAMPLES into his own APPLICATION and modify it under 
// the  terms of  License Agreement between  ABBYY and DEVELOPER.


// ABBYY FineReader Engine 12 Sample

// Helper functions for BSTR handling

#ifndef _BstrWrap_h
#define _BstrWrap_h

#include <WTypes.h>
#include <wchar.h>

// Simple wrapper class for BSTR
class CBstr {
public:
	// Constructors
	CBstr();
	CBstr( const CBstr& string );
	CBstr( const wchar_t* string );
	CBstr( const char* string );

	// Destructor
	~CBstr();

	// Length of the string
	int Length() const;

	// Pointer to the internal buffer
	BSTR* GetBuffer();
	BSTR* operator &();

	// Extractors
	operator const wchar_t*() const;
	const wchar_t* Ptr() const;
	operator wchar_t*() const;
	wchar_t* Ptr();

	// Operators
	CBstr& operator += ( const CBstr& string );
	CBstr operator + ( const CBstr& string ) const;
	CBstr& operator = ( const wchar_t* string );
	CBstr& operator = ( const CBstr& string );
	bool operator != ( const CBstr& string ) const;
	bool operator == ( const CBstr& string ) const;
	wchar_t operator [] ( int index ) const;

private:
	// String buffer
	BSTR stringBuffer;

	// Free string buffer
	void freeBuffer();
};

// Concatenates two strings
CBstr Concatenate( const wchar_t* string1, const wchar_t* string2 );

#endif // _BstrWrap_h
