// � 2017 ABBYY Production LLC
// SAMPLES code is property of ABBYY, exclusive rights are reserved. 
//
// DEVELOPER is allowed to incorporate SAMPLES into his own APPLICATION and modify it under 
// the  terms of  License Agreement between  ABBYY and DEVELOPER.


// ABBYY FineReader Engine 12 Sample

// Helper functions for BSTR handling

#include "BstrWrap.h"
#include <stdlib.h>

CBstr::CBstr()
{
	stringBuffer = ::SysAllocString( L"" );
}

CBstr::CBstr( const CBstr& string )
{
	stringBuffer = ::SysAllocString( string );
}

CBstr::CBstr( const wchar_t* string )
{
	stringBuffer = ::SysAllocString( string );
}

CBstr::CBstr( const char* string )
{
	const size_t length = mbstowcs( NULL, string, INT_MAX );
	stringBuffer = ::SysAllocStringLen( 0, length ); // Allocates length + 1 chars
	mbstowcs( stringBuffer, string, length + 1 );
}

CBstr::~CBstr()
{
	freeBuffer();
}

int CBstr::Length() const
{
	return int( wcslen( stringBuffer ) );
}

BSTR* CBstr::GetBuffer()
{
	freeBuffer();
	return &stringBuffer;
}

BSTR* CBstr::operator &()
{
	return GetBuffer();
}

CBstr::operator const wchar_t*() const
{
	return stringBuffer;
}

const wchar_t* CBstr::Ptr() const
{
	return stringBuffer;
}

CBstr::operator wchar_t*() const
{
	return stringBuffer;
}

wchar_t* CBstr::Ptr()
{
	return stringBuffer;
}

CBstr& CBstr::operator += ( const CBstr& string )
{
	*this = Concatenate( this->stringBuffer, string.stringBuffer );
	return *this;
}

CBstr CBstr::operator + ( const CBstr& string ) const
{
	return Concatenate( this->stringBuffer, string.stringBuffer );
}

CBstr& CBstr::operator = ( const wchar_t* string )
{
	freeBuffer();
	stringBuffer = ::SysAllocString( string );
	return *this;
}

CBstr& CBstr::operator = ( const CBstr& string )
{
	freeBuffer();
	stringBuffer = ::SysAllocString( string );
	return *this;
}

bool CBstr::operator != ( const CBstr& string ) const
{
	if( stringBuffer == 0 || string.stringBuffer == 0 ) {
		return stringBuffer != string.stringBuffer;
	}
	return wcscmp( this->stringBuffer, string.stringBuffer ) != 0;
}

bool CBstr::operator == ( const CBstr& string ) const
{
	if( stringBuffer == 0 || string.stringBuffer == 0 ) {
		return stringBuffer == string.stringBuffer;
	}
	return wcscmp( this->stringBuffer, string.stringBuffer ) == 0;
}

wchar_t CBstr::operator [] ( int index ) const
{
	return stringBuffer[index];
}

void CBstr::freeBuffer()
{
	if( stringBuffer != 0 ) {
		::SysFreeString( stringBuffer );
		stringBuffer = 0;
	}
}

CBstr Concatenate( const wchar_t* string1, const wchar_t* string2 )
{
	CBstr bstr;
	const size_t length = wcslen( string1 ) + wcslen( string2 );
	BSTR* bstrBuffer = bstr.GetBuffer();
	if( bstrBuffer != 0 ) {
		*bstrBuffer = ::SysAllocStringLen( 0, length ); // Allocates length + 1 chars
		if( *bstrBuffer != 0 ) {
			wcscpy( *bstrBuffer, string1 );
			wcscat( *bstrBuffer, string2 );
		}
	}
	return bstr;
}
