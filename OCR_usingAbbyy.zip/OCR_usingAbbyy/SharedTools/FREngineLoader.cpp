// � 2017 ABBYY Production LLC
// SAMPLES code is property of ABBYY, exclusive rights are reserved. 
//
// DEVELOPER is allowed to incorporate SAMPLES into his own APPLICATION and modify it under 
// the  terms of  License Agreement between  ABBYY and DEVELOPER.


// ABBYY FineReader Engine 12 Sample

// Helper functions for loading and unloading FREngine.dll

#include "FREngineLoader.h"
#include "SafePtr.h"
#include "BstrWrap.h"
#include "AbbyyException.h"
#include "../SamplesConfig.h"
#include <time.h>
#include <stdio.h>

// Global FineReader Engine object.
CSafePtr<IEngine> Engine;

// HANDLE to FREngine.dll
static HMODULE libraryHandle = 0;

//	This function loads and initializes FineReader Engine.
void LoadFREngine()
{
#ifdef _DEBUGTIME
	clock_t start, end;
	start = clock();
#endif
	if( Engine != 0 ) {
		// Already loaded
		return;
	}

	CBstr errorDescription = L"Error while loading ABBYY FineReader Engine";
	// First step: load FREngine.dll
	wchar_t *dllpath = ::GetFreDllPath();
	if( libraryHandle == 0 ) {
		libraryHandle = LoadLibraryEx(dllpath, 0, LOAD_WITH_ALTERED_SEARCH_PATH );
		if( libraryHandle == 0 ) {
			DWORD dw = GetLastError();
			throw CAbbyyException( errorDescription );
		}
	}

	// Second step: obtain FineReader Engine object
	typedef HRESULT ( STDAPICALLTYPE* InitializeEngineFunc )( BSTR, BSTR, BSTR, BSTR, BSTR, VARIANT_BOOL, IEngine** );
	InitializeEngineFunc pInitializeEngine = 
		( InitializeEngineFunc )GetProcAddress( libraryHandle, "InitializeEngine" );

	if( pInitializeEngine == 0 ) {
		UnloadFREngine();
		throw CAbbyyException( errorDescription );
	}
	if( FAILED( pInitializeEngine( CBstr( ::GetCustomerProjectId() ), CBstr( ::GetLicensePath() ), 
		CBstr( ::GetLicensePassword() ), CBstr( L"" ), CBstr( L"" ), VARIANT_FALSE, &Engine ) ) )
	{
		// trying to get error message through IErrorInfo
		CBstr description;
		CSafePtr<IErrorInfo> errorInfo;
		if( SUCCEEDED( GetErrorInfo( 0, &errorInfo ) ) ) {
			if( SUCCEEDED( errorInfo->GetDescription( description.GetBuffer() ) ) ) {
				errorDescription = description;
			}
		}
		UnloadFREngine();
		throw CAbbyyException( errorDescription );
	}
#ifdef _DEBUGTIME
	end = clock();
	//printf("LoadFREngine time=%.0f ms\n", (float)(end - start) * 1000 / CLOCKS_PER_SEC);
#endif _DEBUGTIME
}

//	This function deinitializes and unloads FineReader Engine
void UnloadFREngine()
{
#ifdef _DEBUGTIME
	clock_t start, end;
	start = clock();
#endif
	if( libraryHandle == 0 ) {
		return;
	}
	
	// Release Engine object
	Engine = 0;

	// Deinitialize FineReader Engine
	typedef HRESULT ( STDAPICALLTYPE* DeinitializeEngineFunc )();
	DeinitializeEngineFunc pDeinitializeEngine = 
		( DeinitializeEngineFunc )GetProcAddress( libraryHandle, "DeinitializeEngine" );

	if( pDeinitializeEngine == 0 || pDeinitializeEngine() != S_OK ) {
		throw CAbbyyException( L"Error while unloading ABBYY FineReader Engine" );
	}

	// Now it's safe to free the FREngine.dll library
	FreeLibrary( libraryHandle );
	libraryHandle = 0;

#ifdef _DEBUGTIME
	end = clock();
	//printf("UnloadFREngine time=%.0f\n", (float)(end - start) * 1000 / CLOCKS_PER_SEC);
#endif _DEBUGTIME
}
