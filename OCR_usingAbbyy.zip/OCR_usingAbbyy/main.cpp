﻿#include <stdio.h>
#include <iostream>
#include <string>
#include <stdexcept>
#include "./SharedTools/FREngineLoader.h"
#include "./SharedTools/BstrWrap.h"
#include "./SharedTools/AbbyyException.h"
#include "./SharedTools/SafePtr.h"
#include "./SamplesConfig.h"
#include <locale>
#include <codecvt>
#include <fstream>
#include <sstream>
#include <time.h>
#include <vector>



using namespace std;

wstring& replace_all_distinct(wstring& str, const wstring& old_value, const wstring& new_value)
{
	for (wstring::size_type pos(0); pos != wstring::npos; pos += new_value.length()) {
		if ((pos = str.find(old_value, pos)) != wstring::npos)
			str.replace(pos, old_value.length(), new_value);
		else  
			break;
	}

	return  str;
}


std::wstring StringToWString(const std::string& s)
{
	std::wstring temp(s.length(), L' ');
	std::copy(s.begin(), s.end(), temp.begin());
	return temp;
}


std::string WStringToString(const std::wstring& s)
{
	std::string temp(s.length(), ' ');
	std::copy(s.begin(), s.end(), temp.begin());
	return temp;
}

wstring ExtractTxtFromParagraph(IParagraph *paragraph)
{

	CBstr cbstr;
	paragraph->get_Text(&cbstr);   // The text may contain some strange chars only recognized by Abbyy, We need to replace them.
	wstring wstr(cbstr.Ptr());
	wstring wsNewLineTobeConvert = L"\u2028";
	wstring wsNewLine = L"\n";

	replace_all_distinct(wstr, wsNewLineTobeConvert, wsNewLine);
	wcout << wstr;

	return wstr;
}

void deleteallBlocks(IFRDocument *doc, ILayoutBlocks **layoutBlocks)
{
	IFRPages *frpages;
	doc->get_Pages(&frpages);
	IFRPage *frpage;
	frpages->get_Element(0, &frpage);
	ILayout *layout;
	frpage->get_Layout(&layout);
	
	layout->get_Blocks(layoutBlocks);
	(*layoutBlocks)->DeleteAll();

}

void deleteBlocks(IFRDocument *doc, int startIdx, int num, ILayoutBlocks **layoutBlocks)
{
	

	for (int i = 0; i < num; i++)
	{
		IFRPages *frpages;
		doc->get_Pages(&frpages);
		IFRPage *frpage;
		frpages->get_Element(0, &frpage);
		ILayout *layout;
		frpage->get_Layout(&layout);

		layout->get_Blocks(layoutBlocks);
		(*layoutBlocks)->DeleteAt(startIdx);
	}

	IBlock *block;
	(*layoutBlocks)->get_Element(0, &block);
	int color;
	block->get_BackgroundColor(&color);

}
void SetRectangle(IFRDocument *doc, int left, int top, int right, int bottom, ILayoutBlocks **layoutBlocks, IBlock **block)
{
	IFRPages *frpages;
	doc->get_Pages(&frpages);
	IFRPage *frpage;
	frpages->get_Element(0, &frpage);
	ILayout *layout;
	frpage->get_Layout(&layout);
	IRegion *region;
	Engine->CreateRegion(&region);


	region->AddRect(left, top, right, bottom);
	layout->get_Blocks(layoutBlocks);

	int count;
	(*layoutBlocks)->get_Count(&count);
	(*layoutBlocks)->AddNew(BT_Text, region, count, block);
	int color;
	(*block)->get_BackgroundColor(&color);

}

const wchar_t *ExtractTextFromTextBlock(IBlock *pblk)
{
	ITextBlock *ptblk;
	pblk->GetAsTextBlock(&ptblk);
	IText *pblkTxt;
	ptblk->get_Text(&pblkTxt);
	IParagraphs *pblkParagraphs;
	pblkTxt->get_Paragraphs(&pblkParagraphs);

	IParagraph *pparagraph;
	pblkParagraphs->get_Element(0, &pparagraph);
	wstring wstr = ExtractTxtFromParagraph(pparagraph);
	 
	return wstr.c_str();
}

void processImage(char *inputFile, char *outFile = "stdout") {

#ifdef _DEBUGTIME
	clock_t start, end;
	start = clock();
#endif

	//CBstr imagePath = L"C:\\myGit\\2-codeless\\ocr.service\\cdls_ocr\\tests\\sap-fiori-demo-screenshotscheckout_pay.png";
	CBstr imagePath = inputFile;

	CSafePtr<IFRDocument> frDocument = 0;
	try{

#ifdef _DEBUGTIME
		clock_t startCreateDoc, endCreateDoc;
		startCreateDoc = clock();
#endif
		// Create document
		CheckResult(Engine->CreateFRDocument(&frDocument));

		// Add image file to document
		CheckResult(frDocument->AddImageFile(imagePath));

#ifdef _DEBUGTIME
		endCreateDoc = clock();
		printf("Create Document time=%.0f ms\n", (float)(endCreateDoc - startCreateDoc) * 1000 / CLOCKS_PER_SEC);
#endif _DEBUGTIME

#ifdef _DEBUGTIME
		clock_t startProcDoc, endProcDoc;
		startProcDoc = clock();
#endif
		// Process document
		// 0. param

#ifdef _DEBUGTIME
		clock_t startParam, endParam;
		startParam = clock();
#endif
		IDocumentProcessingParams *pdpp;
		Engine->CreateDocumentProcessingParams(&pdpp);
#ifdef _DEBUGTIME
		endParam = clock();
		printf("Create param time=%.0f ms\n", (float)(endParam - startParam) * 1000 / CLOCKS_PER_SEC);
#endif _DEBUGTIME

		// 1. add rect
#ifdef _DEBUGTIME
		clock_t startPreprocess, endPreprocess;
		startPreprocess = clock();
#endif
		frDocument->Preprocess();

		// add rect
		
		ILayoutBlocks *layoutBlocks;
		IBlock *block;
		// test 

		// test end
		IFRPages *frpages;
		frDocument->get_Pages(&frpages);
		IFRPage *frpage;
		frpages->get_Element(0, &frpage);
		ILayout *layout;
		frpage->get_Layout(&layout);
		layout->get_Blocks(&layoutBlocks);

		
		/*
		left = 3;
		top = 830;
		right = 1039;
		bottom = 1005;
		SetRectangle(frDocument, left, top, right, bottom, &layoutBlocks, &block);
		*/

#ifdef _DEBUGTIME
		endPreprocess = clock();
		printf("Preprocess time=%.0f ms\n", (float)(endPreprocess - startPreprocess) * 1000 / CLOCKS_PER_SEC);
#endif _DEBUGTIME

		// 2. Analyze
#ifdef _DEBUGTIME
		clock_t startAnalyze, endAnalyze;
		startAnalyze = clock();
#endif	
		CheckResult(frDocument->Analyze());
#ifdef _DEBUGTIME
		endAnalyze = clock();
		printf("Analyze time=%.0f ms\n", (float)(endAnalyze - startAnalyze) * 1000 / CLOCKS_PER_SEC);
#endif _DEBUGTIME


		// mock rectangle:
		//deleteallBlocks(frDocument, &layoutBlocks);
		deleteBlocks(frDocument, 0, 8, &layoutBlocks);
		deleteBlocks(frDocument, 1, 1, &layoutBlocks);

		int left = 130;
		int top = 625;
		int right = 245;
		int bottom = 643;
		SetRectangle(frDocument, left, top, right, bottom, &layoutBlocks, &block);

		// Now, the page has two same rectangle boxes. One is generated by "Analyze", one is manually set.

		// 3. Recognize
#ifdef _DEBUGTIME
		clock_t startRecognize, endRecognize;
		startRecognize = clock();
#endif	
		CheckResult(frDocument->Recognize());
#ifdef _DEBUGTIME
		endRecognize = clock();
		printf("Recognize time=%.0f ms\n", (float)(endRecognize - startRecognize) * 1000 / CLOCKS_PER_SEC);
#endif _DEBUGTIME

		// 4. Synthesize
#ifdef _DEBUGTIME
		clock_t startSynthesize, endSynthesize;
		startSynthesize = clock();

		//frDocument->Synthesize();

		endSynthesize = clock();
		printf("Synthesize time=%.0f ms\n", (float)(endSynthesize - startSynthesize) * 1000 / CLOCKS_PER_SEC);
#endif _DEBUGTIME

		//CheckResult(frDocument->Process(0));
#ifdef _DEBUGTIME
		endProcDoc = clock();
		printf("Process Document time=%.0f ms\n", (float)(endProcDoc - startProcDoc) * 1000 / CLOCKS_PER_SEC);
#endif _DEBUGTIME

#ifdef _DEBUGTIME
		clock_t startExtract, endExtract;
		startExtract = clock();
#endif
		// Extract text
		/* extract as whole
		CSafePtr<IPlainText> plainText;
		frDocument->get_PlainText(&plainText); // it will contain all pages text. (row by row)

		CBstr cbstr;
		
		plainText->get_Text(&cbstr);   // The text may contain some strange chars only recognized by Abbyy, We need to replace them.

		wchar_t* bstr = (wchar_t*)cbstr; 
		
		// The following convert doesn't help, because the original data contain some special char only parsed by abbyy itself.
		//wstring_convert<codecvt_utf8<wchar_t>, wchar_t> convert;
		//string str = convert.to_bytes(bstr);
		wstring wstr(bstr);
		wstring wsNewLineTobeConvert = L"\u2028";
		wstring wsNewLine = L"\n";

		replace_all_distinct(wstr, wsNewLineTobeConvert, wsNewLine);
		wcout << wstr;
		*/


		
		// Extract for each block

		CSafePtr<IPlainText> plainText;
		frDocument->get_PlainText(&plainText); // it will contain all pages text. (row by row)
		CBstr cbstr_1;
		plainText->get_Text(&cbstr_1);   // The text may contain some strange chars only recognized by Abbyy, We need to replace them.

		wchar_t* bstr = (wchar_t*)cbstr_1;


		vector<const wchar_t*> vecText;
		int blockCount;
		layoutBlocks->get_Count(&blockCount);
		wstring *pwstrs = new wstring[blockCount];
		for (int index = 0; index < blockCount; index++)
		{
			IBlock *pblk;
			layoutBlocks->get_Element(index, &pblk);
			BlockTypeEnum emBlockType;
			pblk->get_Type(&emBlockType);
		    if (emBlockType == BT_Text)
		    {
				//const wchar_t * txt = ExtractTextFromTextBlock(pblk);
				ITextBlock *ptblk;
				
				// get block info
				int bgColor;
				pblk->get_BackgroundColor(&bgColor); // for manually set, it is 16645595, it should be 11252566
				BlockLayerTypeEnum blType;
				pblk->get_BlockLayerType(&blType);
				CBstr name;
				pblk->get_Name(&name);

				//get rectangle info
				IRegion *region;
				pblk->get_Region(&region);
				int rectCount;
				region->get_Count(&rectCount);
				for (int rectIdx = 0; rectIdx < rectCount; ++rectIdx)
				{
					int left, right, top, bottom;
					region->get_Left(rectIdx, &left);
					region->get_Top(rectIdx, &top);
					region->get_Right(rectIdx, &right);
					region->get_Bottom(rectIdx, &bottom);
				}

				pblk->GetAsTextBlock(&ptblk);

				IText *pblkTxt;
				ptblk->get_Text(&pblkTxt);
				IParagraphs *pblkParagraphs;
				pblkTxt->get_Paragraphs(&pblkParagraphs);
				int paraCount;
				pblkParagraphs->get_Count(&paraCount);
				for (int lp = 0; lp < paraCount; lp++)
				{
					IParagraph *pparagraph;
					pblkParagraphs->get_Element(lp, &pparagraph);
					wstring wstr = ExtractTxtFromParagraph(pparagraph);
					pwstrs[index] += wstr;	
				}
				const wchar_t *txt = pwstrs[index].c_str();
				vecText.push_back(txt);
		    }
			else
			{
				const wchar_t *txt = nullptr;
				vecText.push_back(txt);
			}

		}
		
#ifdef _DEBUGTIME
		endExtract = clock();
		printf("\nExtract Text time=%.0f ms\n", (float)(endExtract - startExtract) * 1000 / CLOCKS_PER_SEC);
#endif _DEBUGTIME

		/*if (strcmp(outFile, "stdout") == 0) {
			fprintf(stdout, "%S", bstr);
		}
		else {
			FILE * pFile;
			pFile = fopen(outFile, "wb");
			if(pFile != nullptr)
				fprintf(pFile, "%S", bstr);
		}*/

		
		//for (int i = 0; i < document.Pages.Count; i++)
		//{
		//	IPlainText plainTxt = document.Pages[i].PlainText;
		//	plainTxt.SaveToTextFile(outputFile, TextEncodingTypeEnum.TET_UTF8, CodePageEnum.CP_Null);

		//	string extractedTxt = File.ReadAllText(outputFile);  // note: it contain \r\n
		//	string modifiedTxt = extractedTxt.Replace("\r", "");
		//	Console.WriteLine(i.ToString() + ":" + modifiedTxt);
		//	File.Delete(outputFile);

			//ILayout layout = document.Pages[i].Layout;
			//ILayoutBlocks blocks = layout.Blocks;
			//for (int index = 0; index < blocks.Count; index++)
			//{
			//    IBlock block = blocks[index];
			//    if (block.Type == BlockTypeEnum.BT_Text)
			//    {

			//        ITextBlock textBlockProperties = block.GetAsTextBlock();
			//        //IPlainText plainText = textBlockProperties.PlainText;
			//        IText text = textBlockProperties.Text;
			//        IParagraphs paragraphs = text.Paragraphs;
			//        for (int idx = 0; idx < paragraphs.Count; idx++)
			//        {
			//            calculateStatisticsForParagraph(paragraphs[index]);
			//        }
			//    }

			//}

		//}
	}
	catch (CAbbyyException& e) {
		fprintf(stderr, "%S\n",e.Description());

		// Close document
		frDocument->Close();
	}
	
	frDocument->Close();
#ifdef _DEBUGTIME
	end = clock();
	printf("\ntotal time=%.0f ms\n", (float)(end - start) * 1000 / CLOCKS_PER_SEC);
#endif _DEBUGTIME
}



int main(int argc, char* argv[])
{
#ifdef _DEBUGTIME
	clock_t startMain, endMain;
	startMain = clock();
#endif
	if (argc < 3)
		return -1;

	// load Engine
	LoadFREngine();

	// Setup FREngine
	// Possible profile names are:
	//   "DocumentConversion_Accuracy", "DocumentConversion_Speed",
	//   "DocumentArchiving_Accuracy", "DocumentArchiving_Speed",
	//   "BookArchiving_Accuracy", "BookArchiving_Speed",
	//   "TextExtraction_Accuracy", "TextExtraction_Speed",
	//   "FieldLevelRecognition",
	//   "BarcodeRecognition_Accuracy", "BarcodeRecognition_Speed",
	//   "HighCompressedImageOnlyPdf",
	//   "BusinessCardsProcessing",
	//   "EngineeringDrawingsProcessing",
	//   "Version9Compatibility",
	//   "Default"
	//CheckResult(Engine->LoadPredefinedProfile(CBstr(L"TextExtraction_Speed")));
	CheckResult(Engine->LoadPredefinedProfile(L"FieldLevelRecognition")); 
	// Parse args
	char *chInputImageFileName = argv[1];
	char *outFile = argv[2];

	if (strlen(chInputImageFileName) <= 0)
		return -1;

	if (strlen(outFile) <= 0)
		outFile = "stdout";
	// Process image
	processImage(chInputImageFileName, outFile);

	// Unload ABBYY FineReader Engine

	UnloadFREngine();

#ifdef _DEBUGTIME
	endMain = clock();
	//printf("total time=%.0f ms\n", (float)(endMain - startMain) * 1000 / CLOCKS_PER_SEC);
	getchar();
#endif _DEBUGTIME

}
