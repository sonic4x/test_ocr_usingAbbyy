﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using FREngine;
using Sample;
using System.Diagnostics;

namespace OCR_usingAbbyy_CSharp
{
    class Program
    {
        static EngineLoader engineLoader = null;

        static private void logTime(string desc, double value)
        {
#if DEBUG
            Console.WriteLine(string.Format(desc + " time cost: {0}ms", value));          
#endif
        }
        static private void loadEngine()
        {
            if (engineLoader == null)
            {
                engineLoader = new EngineLoader();
            }
        }


        static private void unloadEngine()
        {
            if (engineLoader != null)
            {
                engineLoader.Dispose();
                engineLoader = null;
            }
        }

        static private void loadProfile()
        {
            engineLoader.Engine.LoadPredefinedProfile("FieldLevelRecognition");
            // Possible profile names are:
            //   "DocumentConversion_Accuracy", "DocumentConversion_Speed",
            //   "DocumentArchiving_Accuracy", "DocumentArchiving_Speed",
            //   "BookArchiving_Accuracy", "BookArchiving_Speed",
            //   "TextExtraction_Accuracy", "TextExtraction_Speed",
            //   "FieldLevelRecognition",
            //   "BarcodeRecognition_Accuracy", "BarcodeRecognition_Speed",
            //   "HighCompressedImageOnlyPdf",
            //   "BusinessCardsProcessing",
            //   "EngineeringDrawingsProcessing",
            //   "Version9Compatibility",
            //   "Default"
        }

        static private void setupFREngine()
        {
            loadProfile();
        }


        static private void processImage(string inputFile, string outFile)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();

#region 0.Load profile
            Stopwatch sw_loadprofile = new Stopwatch();
            sw_loadprofile.Start();
            setupFREngine();
            sw_loadprofile.Stop();
            TimeSpan ts2_loadprofile = sw_loadprofile.Elapsed;
            logTime("LoadProfile", ts2_loadprofile.TotalMilliseconds);
            
#endregion

#region 1.Create Document
            Stopwatch sw_CreateDoc = new Stopwatch();
            sw_CreateDoc.Start();

            // Create document
            FREngine.FRDocument document = engineLoader.Engine.CreateFRDocument();
            PrepareImageMode prepareImageMode = document.Application.CreatePrepareImageMode();

            //prepareImageMode.EnhanceLocalContrast = true;  // it will be worse using this
            //prepareImageMode.AutoOverwriteResolution = true; // it's default. dpi: 300,300
            //prepareImageMode.PhotoProcessingMode = PhotoProcessingModeEnum.PPM_TreatAsPhoto;
            document.AddImageFile(inputFile, prepareImageMode, null);


            //string imagePath = Path.Combine(FreConfig.GetSamplesFolder(), @"ImageData\IOS_1_Ham_Cart_Input_Button_cropped1.png");
            //string absBasePath = System.AppDomain.CurrentDomain.BaseDirectory;
            //string absImagePath = Path.Combine(absBasePath, imagePath);
            string outputFile = Path.Combine(FreConfig.GetSamplesFolder(), @"ImageData_output\out1.txt");
            // Don't recognize PDF file with a textual content, just copy it
            //if( engineLoader.Engine.IsPdfWithTextualContent( imagePath, null ) ) {
            //    displayMessage( "Copy results..." );
            //    string resultPath = Path.Combine( FreConfig.GetSamplesFolder(), 
            //        @"SampleImages\Demo_copy.pdf" );
            //    File.Copy( imagePath, resultPath, true );
            //    return;
            //}


            //FREngine.FRDocument document = engineLoader.Engine.CreateFRDocumentFromImage(absImagePath);

            sw_CreateDoc.Stop();
            TimeSpan ts2_sw_CreateDoc = sw_CreateDoc.Elapsed;
            logTime("Create doc", ts2_sw_CreateDoc.TotalMilliseconds);
            
#endregion

            try
            {


#region 2.Param preparation
                
                Stopwatch sw_param = new Stopwatch();
                sw_param.Start();

                //ObjectsExtractionParams objExtractParam = document.Application.CreateObjectsExtractionParams();
                //objExtractParam.DetectTextOnPictures = true;
                //objExtractParam.EnableAggressiveTextExtraction = true;

                IDocumentProcessingParams dpp = document.Application.CreateDocumentProcessingParams();
                IPageProcessingParams ppp = dpp.PageProcessingParams;

                // preprocess on page
                IPagePreprocessingParams pagePreprocessParams = ppp.PagePreprocessingParams;
                //pagePreprocessParams.CorrectShadowsAndHighlights = FREngine.ThreeStatePropertyValueEnum.TSPV_Yes;
                //pagePreprocessParams.CropImage = FREngine.ThreeStatePropertyValueEnum.TSPV_Yes;

                // Analysis param
                // tells FineReader Engine that text blocks can be located anywhere on the page.Isolated text blocks are detected during layout analysis
                IPageAnalysisParams pageAnalysisParam = ppp.PageAnalysisParams;
                ////pageAnalysisParam.EnableTextExtractionMode = true;
                //pageAnalysisParam.EnableExhaustiveAnalysisMode = true;


                // object extract param
                IObjectsExtractionParams objectExtractParam = ppp.ObjectsExtractionParams;
                ////objectExtractParam.DetectTextOnPictures = true;
                ////objectExtractParam.EnableAggressiveTextExtraction = true;

                // recognize param
                IRecognizerParams recognizerParams = ppp.RecognizerParams;
                ////recognizerParams.LowResolutionMode = true;
                //recognizerParams.ExactConfidenceCalculation = true;     //make a score, it will slow down a bit

                sw_param.Stop();
                TimeSpan ts2_sw_param = sw_param.Elapsed;
                logTime("create param", ts2_sw_param.TotalMilliseconds);

#endregion

#region 3.preprocess
                /////////////////////////////////////////////
                Stopwatch sw_Preprocess = new Stopwatch();
                sw_Preprocess.Start();
                document.Preprocess();
                sw_Preprocess.Stop();
                TimeSpan ts2_Preprocess = sw_Preprocess.Elapsed;
                logTime("Preprocess", ts2_Preprocess.TotalMilliseconds);
                
#endregion

#region 4.Analyze and get/create blocks
                
                Stopwatch sw_Analyze = new Stopwatch();
                sw_Analyze.Start();
                //document.Analyze(ppp.PageAnalysisParams, ppp.ObjectsExtractionParams, ppp.RecognizerParams);
                document.Analyze();

                for (int pageidx = 0; pageidx < document.Pages.Count; pageidx++)
                {
                    FREngine.ILayout layout = document.Pages[pageidx].Layout;
                    bool hasTextBlock = false;
                    for (int idx = 0; idx < layout.Blocks.Count; idx++)
                    {
                        ITextBlock tb = layout.Blocks[idx].GetAsTextBlock();
                        if (tb == null)
                            continue;
                        bool adi = tb.AnalysisParams.AutodetectInversion;
                        tb.AnalysisParams.AutodetectInversion = true;
                        hasTextBlock = true;
                    }
                    if (!hasTextBlock)
                    {
                        //create a textblock manually
                        FREngine.IRegion region = document.Application.CreateRegion();
                        region.AddRect(0, 0, layout.Width - 1, layout.Height - 1);
                        FREngine.IBlock block = layout.Blocks.AddNew(FREngine.BlockTypeEnum.BT_Text, region, layout.Blocks.Count);
                        block.GetAsTextBlock().AnalysisParams.AutodetectInversion = true;
                    }
                }

                TimeSpan ts2_Analyze = sw_Analyze.Elapsed;
                logTime("Analyze", ts2_Analyze.TotalMilliseconds);
#endregion

#region 5.Recognize
                //////////////////////////////////////////
                Stopwatch sw_Recognize = new Stopwatch();
                sw_Recognize.Start();
                //document.Recognize(null, ppp.ObjectsExtractionParams);
                document.Recognize();
                TimeSpan ts2_Recognize = sw_Recognize.Elapsed;
                logTime("Recognize", ts2_Recognize.TotalMilliseconds);
#endregion

#region 6.Synthesize
                //////////////////////////////////////////
                Stopwatch sw_Synthesize = new Stopwatch();
                sw_Synthesize.Start();
                document.Synthesize(null);
                TimeSpan ts2_Synthesize = sw_Synthesize.Elapsed;
                logTime("Synthesize", ts2_Synthesize.TotalMilliseconds);
                
#endregion

                //document.Preprocess(null, objExtractParam, null, null);
                //document.Analyze(null, objExtractParam, null);
                //document.Recognize(null, objExtractParam);
                //document.Process(dpp as DocumentProcessingParams);

                //IPlainText plainText = document.PlainText; // it will contain all pages text. (row by row)
                //string txt = plainText.Text;   // contain some strange char, which can only be parsed by FR.
                //Console.WriteLine(txt);

                //plainText.SaveToTextFile(outputFile, TextEncodingTypeEnum.TET_UTF8, CodePageEnum.CP_Null);
                //string extractedTxt = File.ReadAllText(outputFile);  // note: it contain \r\n
                //string modifiedTxt = extractedTxt.Replace("\r", "");
                //Console.WriteLine(modifiedTxt);
                //File.Delete(outputFile);

#region 7.Extract text
                //////////////////////////////////////////
                Stopwatch sw_extract = new Stopwatch();
                sw_extract.Start();

                for (int i = 0; i < document.Pages.Count; i++)
                {
                    IPlainText plainTxt = document.Pages[i].PlainText;
                    string text = plainTxt.Text;
                    Console.WriteLine("extracted text: {0}", text);

                    //plainTxt.SaveToTextFile(outputFile, TextEncodingTypeEnum.TET_UTF8, CodePageEnum.CP_Null);
                    //string extractedTxt = File.ReadAllText(outputFile);  // note: it contain \r\n
                    //string modifiedTxt = extractedTxt.Replace("\r", "");
                    //Console.WriteLine(i.ToString() + ":" + modifiedTxt);
                    //File.Delete(outputFile);

                    //ILayout layout = document.Pages[i].Layout;
                    //ILayoutBlocks blocks = layout.Blocks;
                    //for (int index = 0; index < blocks.Count; index++)
                    //{
                    //    IBlock block = blocks[index];
                    //    if (block.Type == BlockTypeEnum.BT_Text)
                    //    {

                    //        ITextBlock textBlockProperties = block.GetAsTextBlock();
                    //        IText blocktext = textBlockProperties.Text;
                    //        IParagraphs paragraphs = blocktext.Paragraphs;
                    //        for (int idx = 0; idx < paragraphs.Count; idx++)
                    //        {
                    //            calculateStatisticsForParagraph(paragraphs[idx]);
                    //        }
                    //    }
                    //}
                }

                sw_extract.Stop();
                TimeSpan ts2_sw_extract = sw_extract.Elapsed;
                logTime("extract", ts2_sw_extract.TotalMilliseconds);
                
#endregion
            }
            catch (Exception)
            {

            }
            finally
            {

                // Close document
                Stopwatch sw_Close = new Stopwatch();
                sw_Close.Start();

                document.Close();

                sw_Close.Stop();
                TimeSpan ts2_sw_Close = sw_Close.Elapsed;
                logTime("closeDoc", ts2_sw_Close.TotalMilliseconds);

                sw.Stop();
                TimeSpan ts2 = sw.Elapsed;
                logTime("total", ts2.TotalMilliseconds);

            }
        }
        static void calculateStatisticsForParagraph(IParagraph paragraph)
        {
            calculateCharStatisticsForParagraph(paragraph);

            //calculateWordStatisticsForParagraph(paragraph);
        }

        static void calculateCharStatisticsForParagraph(IParagraph paragraph)
        {
            string txt = paragraph.Text;
            Console.WriteLine(txt);


            for (int index = 0; index < paragraph.Text.Length; index++)
            {
                calculateStatisticsForChar(paragraph, index);
            }


        }

        static void calculateStatisticsForChar(IParagraph paragraph, int charIndex)
        {
            ICharParams charParams = engineLoader.Engine.CreateCharParams();
            paragraph.GetCharParams(charIndex, charParams);

            //for (int i = 0; i < charParams.CharacterRecognitionVariants.Count; i++)
            //{
            //    string ch = charParams.CharacterRecognitionVariants[i].Character;
            //    int score = charParams.CharacterRecognitionVariants[i].CharConfidence;
            //}

            if (charParams.IsSuspicious)
            {
                Console.WriteLine("IsSuspicious");
            }

            if (isUnrecognizedSymbol(paragraph.Text[charIndex]))
            {
                Console.WriteLine("isUnrecognizedSymbol");
            }

            if (paragraph.Text[charIndex] != ' ')
            {
                //Console.WriteLine("good char");
            }
        }

        static bool isUnrecognizedSymbol(char symbol)
        {
            //it is special constant used by FREngine recogniser
            return (symbol == 0x005E);
        }


        static void Main(string[] args)
        {
            if (args.Length < 2)
                return;

            // Parse args
            string chInputImageFileName = args[0];
            string outFile = args[1];

            if (string.IsNullOrEmpty(chInputImageFileName))
                return;
            try
            {
                loadEngine();

                // Process with ABBYY FineReader Engine
                processImage(chInputImageFileName, outFile);

                // Unload ABBYY FineReader Engine
                unloadEngine();

                Console.ReadLine();
            }
            catch (Exception error)
            {
                Console.WriteLine(error.Message);
            }


            
        }
    }
}
