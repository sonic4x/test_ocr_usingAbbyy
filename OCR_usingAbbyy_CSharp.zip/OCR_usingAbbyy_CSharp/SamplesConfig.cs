// (c) 2017 ABBYY Production LLC
// SAMPLES code is property of ABBYY, exclusive rights are reserved. 
//
// DEVELOPER is allowed to incorporate SAMPLES into his own APPLICATION and modify it under 
// the  terms of  License Agreement between  ABBYY and DEVELOPER.


// Auto-generated config-file for FineReader Engine C-Sharp samples

using System;

class FreConfig {
    // Folder with FRE dll
    public static String GetDllFolder() {
        //if( is64BitConfiguration() ) {
            return "C:\\Program Files\\ABBYY SDK\\12\\FineReader Engine\\Bin64";
        //} else {
        //    return "Directory\\where\\x86\\dll\\resides";
        //}
    }

    // Return customer project id for FRE
    public static String GetCustomerProjectId() {
        return "JYB7VXmncFYRx26P3Hzg";
    }

    // Return path to license file
    public static String GetLicensePath() {
        return "";
    }

    // Return license password
    public static String GetLicensePassword() {
        return "";
    }

    // Return full path to Samples directory
    public static String GetSamplesFolder() {
        return @"..\..\..\..";
    }

    // Determines whether the current configuration is a 64-bit configuration
    private static bool is64BitConfiguration() {
        return System.IntPtr.Size == 8;
    }
}
